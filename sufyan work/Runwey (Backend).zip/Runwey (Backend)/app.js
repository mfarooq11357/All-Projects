// //----> LocalHost:-

// const createError = require('http-errors');
// const compression = require('compression');
// const express = require('express');
// const path = require('path');
// const cookieParser = require('cookie-parser');
// const logger = require('morgan');
// const cors = require('cors');
// require('dotenv').config();
// const mongoose = require('mongoose');
// const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
// // const PORT = process.env.PORT || 3000;

// const indexRouter = require('./routes/index');
// const usersRouter = require('./routes/userRouter');
// const categoryRouter = require('./routes/categoryRouter');
// const contentRouter = require('./routes/contentRouter');
// const chatRouter = require('./routes/chatRouter');
// const messageRouter = require('./routes/messageRouter');
// const aboutAndPrivacyRouter = require('./routes/aboutAndPrivacyRouter');
// const bannerRouter = require('./routes/bannerRouter');
// const ratingRouter = require('./routes/ratingRouter');
// const wishlistRouter = require('./routes/wishlistRouter');
// const subscribeRouter = require('./routes/subscriptionRouter');
// const questionRouter = require('./routes/questionRouter');
// const answerRouter = require('./routes/answerRouter');
// const paymentRouter = require('./routes/paymentRouter');
// const notificationRouter = require('./routes/notificationRouter');
// const mySubscriptionRouter = require('./routes/mySubscriptionRouter');
// const reportRouter = require('./routes/reportRouter');

// const app = express();

// // Connect to the MongoDB databasee
// mongoose.connect('mongodb://localhost:27017/runwey', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// mongoose.connection.on('error', err => {
//   console.error("MongoDB connection error:", err);
// });

// mongoose.connection.once('open', () => {
//   console.log("Connected to MongoDB");
// });

// // Enable CORS
// app.use(cors({
//   origin: "*",
//   optionsSuccessStatus: 200
// }));

// // Make public folder static for publicly access
// app.use(express.static('public'));

// // View engine setup
// app.set('views', path.join(__dirname, 'views'));
// app.set('view engine', 'jade');

// app.use(logger('dev'));
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(cookieParser());
// // Use compression middleware
// app.use(compression());
// app.use(express.static(path.join(__dirname, 'public')));

// app.use('/', indexRouter);
// app.use('/api/users', usersRouter);
// app.use('/api/categories', categoryRouter);
// app.use('/api/contents', contentRouter);
// app.use('/api', aboutAndPrivacyRouter);
// app.use('/api', bannerRouter);
// app.use('/api', wishlistRouter);
// app.use('/api/rating', ratingRouter);
// app.use('/api/subscribe', subscribeRouter);
// app.use('/api/question', questionRouter);
// app.use('/api/answer', answerRouter);
// app.use('/api/payment', paymentRouter);
// app.use('/api/chats', chatRouter);
// app.use('/api/messages', messageRouter);
// app.use('/api/notification', notificationRouter);
// app.use('/api/my-subscription', mySubscriptionRouter);
// app.use('/api/report', reportRouter);

// app.get('/api/test', (req, res) => {
//   res.send('HelloWorld');
// });

// app.use('/public/image', express.static(__dirname + '/public/image/'));

// // Catch 404 and forward to error handler
// app.use(function (req, res, next) {
//   next(createError(404));
// });

// // General error handler
// app.use((err, req, res, next) => {
//   if (res.headersSent) {
//     return next(err);
//   }

//   console.error("Error:", err.message);
//   res.status(err.status || 500).json({
//     status: err.status || "error",
//     message: err.message || 'There was an error!',
//   });
// });

// app.listen(3000, () => {
//   console.log(`Server running on port 3000`);
// });

// module.exports = app;

//--> Production:-

const createError = require('http-errors');
const compression = require('compression');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require('cors');
require('dotenv').config();
const mongoose = require('mongoose');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
// const PORT = process.env.PORT || 3000;

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/userRouter');
const categoryRouter = require('./routes/categoryRouter');
const contentRouter = require('./routes/contentRouter');
const chatRouter = require('./routes/chatRouter');
const messageRouter = require('./routes/messageRouter');
const aboutAndPrivacyRouter = require('./routes/aboutAndPrivacyRouter');
const bannerRouter = require('./routes/bannerRouter');
const ratingRouter = require('./routes/ratingRouter');
const wishlistRouter = require('./routes/wishlistRouter');
const subscribeRouter = require('./routes/subscriptionRouter');
const questionRouter = require('./routes/questionRouter');
const answerRouter = require('./routes/answerRouter');
const paymentRouter = require('./routes/paymentRouter');
const notificationRouter = require('./routes/notificationRouter');
const mySubscriptionRouter = require('./routes/mySubscriptionRouter');
const reportRouter = require('./routes/reportRouter');

const app = express();

// Connect to the MongoDB databasee
mongoose.connect(process.env.MONGO_URI || 'mongodb://167.99.89.66:27017/runwey', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on('error', err => {
  console.error("MongoDB connection error:", err);
});

mongoose.connection.once('open', () => {
  console.log("Connected to MongoDB");
});

// Enable CORS
app.use(cors({
  origin: "*",
  optionsSuccessStatus: 200
}));

// Make public folder static for publicly access
app.use(express.static('public'));

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
// Use compression middleware
app.use(compression());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/api/users', usersRouter);
app.use('/api/categories', categoryRouter);
app.use('/api/contents', contentRouter);
app.use('/api', aboutAndPrivacyRouter);
app.use('/api', bannerRouter);
app.use('/api', wishlistRouter);
app.use('/api/rating', ratingRouter);
app.use('/api/subscribe', subscribeRouter);
app.use('/api/question', questionRouter);
app.use('/api/answer', answerRouter);
app.use('/api/payment', paymentRouter);
app.use('/api/chats', chatRouter);
app.use('/api/messages', messageRouter);
app.use('/api/notification', notificationRouter);
app.use('/api/my-subscription', mySubscriptionRouter);
app.use('/api/report', reportRouter);

app.get('/api/test', (req, res) => {
  res.send('Hello Josh Arj testing pipeline!!! Muhammad Safyan Tariq..test 6');
});

app.use('/public/image', express.static(__dirname + '/public/image/'));

// Catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// General error handler
app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  console.error("Error:", err.message);
  res.status(err.status || 500).json({
    status: err.status || "error",
    message: err.message || 'There was an error!',
  });
});

// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

module.exports = app;
