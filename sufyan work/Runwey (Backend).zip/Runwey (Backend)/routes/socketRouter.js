// const express = require('express');

// const router = express.Router();

// router.post('/meow', socketController);

// module.exports = router;