const express = require('express');
const { payment, transaction, incomeDetails, earningChart, yearlyIncomeChart, monthlyIncome, yearlyIncome, weeklyIncome, yearlyIncomeCha, paymentfromStore, transferMoneyToBankAccount, createConnectedAccount, fetchAllConnectedAccounts, reverseBalance, listTransfers, connectingAccDetails } = require('../controllers/paymentController');
const { isValidUser } = require('../middleWares/auth');
const router = express.Router();


router.post('/', isValidUser, payment);
router.get('/connecting-acc-details', isValidUser, connectingAccDetails);
router.post('/store', isValidUser, paymentfromStore);
router.post('/pay-creator', isValidUser, transferMoneyToBankAccount);
router.post('/create-connected-account', createConnectedAccount);
router.post('/reverse-balance', reverseBalance);
router.get('/income', isValidUser, incomeDetails);
router.get('/transaction', isValidUser, transaction);
router.get('/earning', earningChart);
router.get('/monthly-income', yearlyIncomeChart);
router.get('/yearly-income', yearlyIncome);
router.get('/weekly-income', weeklyIncome);
router.get('/fetch-transfers', listTransfers);
router.get('/fetch-connected-accounts', fetchAllConnectedAccounts);
router.get('/yearly-income-chart', isValidUser, yearlyIncomeCha);

module.exports = router;